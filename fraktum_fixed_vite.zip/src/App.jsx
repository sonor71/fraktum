import { useState } from 'react'
import { motion } from 'framer-motion'

const exampleCards = [
  { name: "Прах Вечной Тени", rarity: "Архаичная", type: "Эффект" },
  { name: "Клятва Крови", rarity: "Легендарная", type: "Событие" },
  { name: "Зов Иллюзии", rarity: "Мифическая", type: "Тактика" },
  { name: "Тьма Надежды", rarity: "Редкая", type: "Эффект" },
  { name: "Огненный Клинок Севера", rarity: "Экзотическая", type: "Событие" }
]

export default function App() {
  const [packOpened, setPackOpened] = useState(false)
  const [cards, setCards] = useState([])

  const openPack = () => {
    setPackOpened(true)
    setCards(shuffle(exampleCards).slice(0, 5))
  }

  const shuffle = (arr) => arr.sort(() => Math.random() - 0.5)

  return (
    <div style={{ background: 'linear-gradient(to bottom right, #1a1a1a, #000)', color: 'white', minHeight: '100vh', padding: '2rem' }}>
      <h1 style={{ fontSize: '2.5rem', textAlign: 'center', marginBottom: '2rem' }}>🕯️ FRAKTUM: ПРОТОКОЛ ВЕЧНОСТИ</h1>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '2rem' }}>
        <button onClick={openPack} style={{ padding: '1rem 2rem', background: '#5b21b6', border: 'none', borderRadius: '1rem', fontSize: '1.2rem' }}>
          Открыть пак (5 карт)
        </button>
      </div>
      {packOpened && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
          {cards.map((card, index) => (
            <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.2 }}>
              <div style={{ background: '#2d2d2d', borderRadius: '1rem', padding: '1rem', textAlign: 'center', border: '2px solid #7e22ce' }}>
                <h2 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>{card.name}</h2>
                <p style={{ fontStyle: 'italic', color: '#a855f7' }}>{card.type}</p>
                <p style={{ color: '#facc15' }}>{card.rarity}</p>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
